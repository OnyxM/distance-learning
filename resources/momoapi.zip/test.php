<?php

  //require_once 'momoapi.php';

  //$momo = new  MOMOAPI();

	//				  amount  237+number	trans_id_in_your_app
  // echo $momo->disTransfer("100","237675518226","transaction_id");
   //this a deposit operation, takes
   //echo $momo->disTransferStatus("6cd14c3c-c531-4bae-9250-a63569ccdfa2");
   //this is to check the status
   //echo $momo->disCheckBalance();
   //this is to check the available balance in this disbursement api account
   //echo $momo->disCheckAccountHolder("237675669236");
   //this is to check if the number has a mobile money account
   
   
   //echo $momo->colRequestToPay("200","237675518226","transaction_id");
   //echo $momo->colStatus("1c2d671d-d00d-43a9-92ea-25ea8aab9cb1");
   //echo $momo->colCheckBalance();
   //echo $momo->colCheckAccountHolder("237675518226");21592
   

 ?>
